# Proyecto 2 · Redes Neuronales Estáticas: predicción de quiebra

Métodos de Inteligencia Artificial, ITESO.

## Estructura

```
01_datos_y_estructura.ipynb    # Persona 1: portada, introducción, objetivos, base de datos y tratamiento
datos/
  crudos/taiwan_bankruptcy.csv # Base original (UCI, Taiwanese Bankruptcy Prediction)
  tratados/                    # Datos listos para usar en los modelos
img/                           # Logo y gráficas del reporte
```

## Datos tratados (`datos/tratados/`)

| Archivo | Uso |
|---|---|
| `entrenamiento_normalizado.csv` | Entrenar la red competitiva y ADALINE / perceptrón (5 451 empresas) |
| `prueba_normalizado.csv` | Evaluar los modelos (1 363 empresas) |
| `empresas_nuevas_normalizado.csv` | Las 5 empresas de la predicción final (no usar para entrenar) |
| `empresas_nuevas_original.csv` | Las mismas 5 empresas sin normalizar |
| `parametros_normalizacion.csv` | Percentiles, media y desviación usados en el tratamiento |
| `ranking_variables.csv` | Apoyo para la selección de variables |

Tratamiento: se eliminan las variables con escala inconsistente, se aplica winsorización con los percentiles 1 y 99 y luego normalización Z-score. Todos los parámetros se calculan solo con el entrenamiento. Quedan 86 variables y la columna `quiebra` (1 = quiebra, 0 = sana).

```python
import pandas as pd
entrenamiento = pd.read_csv("datos/tratados/entrenamiento_normalizado.csv", index_col="id_empresa")
X = entrenamiento.drop(columns="quiebra")
y = entrenamiento["quiebra"]
```

> Ojo: solo el 3.2 % de las empresas quebró. Revisen la precisión y el recall de la clase "quiebra", no solo la exactitud.

## Pendiente (resto del equipo)

- Selección de variables y su justificación (4a)
- Red competitiva y análisis de los grupos (2, 4d)
- ADALINE / perceptrón y medidas de desempeño (3, 4e)
- Predicción de las 5 empresas nuevas (5)
- Conclusiones (6)
